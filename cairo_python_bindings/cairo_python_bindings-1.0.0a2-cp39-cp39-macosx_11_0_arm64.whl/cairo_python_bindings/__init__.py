from .cairo_python_bindings import *

__doc__ = cairo_python_bindings.__doc__
if hasattr(cairo_python_bindings, "__all__"):
    __all__ = cairo_python_bindings.__all__